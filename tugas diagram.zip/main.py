
from autocar_rpl import AutoCarRPL
from mio import Mio

# Membuat objek mobil AutoCarRPL dengan komponen yang terhubung
mobil = AutoCarRPL("Bensin", 100, 4, "Diesel", "Power Steering", "Solar")
mobil.start()
mobil.drive()

# Membuat objek Mio sebagai turunan dari AutoCarRPL
mio = Mio("Bensin", 80, 2, "Bensin", "Manual", "Bensin")
mio.start()
mio.drive()
