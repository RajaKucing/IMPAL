
class Mesin:
    def __init__(self, tipe):
        self.tipe = tipe
