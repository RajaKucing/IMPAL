
from transportasi import Transportasi
from roda import Roda
from mesin import Mesin
from setir import Setir
from fuel import Fuel

class AutoCarRPL(Transportasi):
    def __init__(self, bahan_bakar, kecepatan, jumlah_roda, tipe_mesin, tipe_setir, jenis_bahan_bakar):
        super().__init__(bahan_bakar, kecepatan)
        self.roda = Roda(jumlah_roda)
        self.mesin = Mesin(tipe_mesin)
        self.setir = Setir(tipe_setir)
        self.bahan_bakar_obj = Fuel(jenis_bahan_bakar)

    def start(self):
        print("Mobil mulai berjalan dengan bahan bakar", self.bahan_bakar_obj.jenis)

    def drive(self):
        print("Mobil sedang berjalan dengan kecepatan", self.kecepatan, "km/jam.")
