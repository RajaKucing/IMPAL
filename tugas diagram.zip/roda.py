
class Roda:
    def __init__(self, jumlah):
        self.jumlah = jumlah
