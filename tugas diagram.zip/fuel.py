
class Fuel:
    def __init__(self, jenis):
        self.jenis = jenis
