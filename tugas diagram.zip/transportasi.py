
from abc import ABC, abstractmethod

class Transportasi(ABC):
    def __init__(self, bahan_bakar, kecepatan):
        self.bahan_bakar = bahan_bakar
        self.kecepatan = kecepatan

    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def drive(self):
        pass
