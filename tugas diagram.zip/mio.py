
from autocar_rpl import AutoCarRPL

class Mio(AutoCarRPL):
    def __init__(self, bahan_bakar, kecepatan, jumlah_roda, tipe_mesin, tipe_setir, jenis_bahan_bakar):
        super().__init__(bahan_bakar, kecepatan, jumlah_roda, tipe_mesin, tipe_setir, jenis_bahan_bakar)
